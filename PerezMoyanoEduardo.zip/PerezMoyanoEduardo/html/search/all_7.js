var searchData=
[
  ['setcoeficiente',['setCoeficiente',['../classed_1_1Monomio.html#a259fcdd7c96549aa053ffb4ac69af07f',1,'ed::Monomio']]],
  ['setgrado',['setGrado',['../classed_1_1Monomio.html#ae5ff9fdeb412ee9197f5395942d8ef47',1,'ed::Monomio::setGrado()'],['../classed_1_1Polinomio.html#a2387bb72b00d6d62daac94a27129d1fe',1,'ed::Polinomio::setGrado()']]],
  ['setpolinomio',['setPolinomio',['../classed_1_1Polinomio.html#a76864a912e2301a813c08a51b743fa26',1,'ed::Polinomio']]],
  ['setterminos',['setTerminos',['../classed_1_1Polinomio.html#acf2aa0cc5b63144eeffc603e6de0d9a3',1,'ed::Polinomio']]],
  ['sumavector',['sumaVector',['../classed_1_1Polinomio.html#a58c42d9ddeaf9d4a3776af389809e2a9',1,'ed::Polinomio']]]
];
