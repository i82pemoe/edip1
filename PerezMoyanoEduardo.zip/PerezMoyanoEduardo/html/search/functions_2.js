var searchData=
[
  ['getcoeficiente',['getCoeficiente',['../classed_1_1Monomio.html#a1fa653597b00d3ebf69b26d84949051a',1,'ed::Monomio']]],
  ['getgrado',['getGrado',['../classed_1_1Monomio.html#a22fd67c971fbbc239e882a0adc0f3ef2',1,'ed::Monomio::getGrado()'],['../classed_1_1Polinomio.html#a6652a2361f03daf45b38a97e8b146d15',1,'ed::Polinomio::getGrado()']]],
  ['getmonomio',['getMonomio',['../classed_1_1Polinomio.html#ac2b20ed929a98c449c635cc70dc82f20',1,'ed::Polinomio']]],
  ['getpolinomio',['getPolinomio',['../classed_1_1Polinomio.html#a80086e21883c1108260006302135eade',1,'ed::Polinomio']]],
  ['getterminos',['getTerminos',['../classed_1_1Polinomio.html#a9c54328800c74a91e04cb22f968e7510',1,'ed::Polinomio']]]
];
