var searchData=
[
  ['polinomio',['Polinomio',['../classed_1_1Polinomio.html',1,'ed']]],
  ['polinomio',['Polinomio',['../classed_1_1Polinomio.html#ad2a480e2e09d0afa8f58907f5460a357',1,'ed::Polinomio::Polinomio(Polinomio const &amp;p)'],['../classed_1_1Polinomio.html#ab357d5df6da0d216f079f485937b6266',1,'ed::Polinomio::Polinomio(int grado=0, int terminos=0, int n=0)']]],
  ['polinomiointerfaz',['PolinomioInterfaz',['../classed_1_1PolinomioInterfaz.html',1,'ed']]]
];
