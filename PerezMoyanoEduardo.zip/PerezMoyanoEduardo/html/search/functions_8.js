var searchData=
[
  ['testpolinomio',['testPolinomio',['../classed_1_1Polinomio.html#a1a2237c522e6e6907d119d77dcc4aca5',1,'ed::Polinomio']]]
];
